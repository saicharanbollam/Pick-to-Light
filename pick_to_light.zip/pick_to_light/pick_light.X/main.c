/*
 * NAME: B SAI CHARAN REDDY
 * DATE:11/12/2024
 * DESCRIPTION:PEAK TO LIGHT PROJECT
 */
#include <xc.h>
#include "main.h"
#include "external_int.h"
#include "isr.h"
#include "ssd_display.h"
#include"digital_keypad.h"
#include "eeprom.h"
#include "can.h"


static unsigned char ssd[MAX_SSD_CNT];
static unsigned char digit[] = {ZERO, ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE};

unsigned int key;
int flag,flag1,flag2,s_field=0,p_field=0,rec=0,val;
char  i=0,j=0,k=0,l=0,a=0,b=0,c=0,d=0;

static void init_config(void) {

   
   init_ssd_control();
   init_can();
    TRISC=0x0F; 
    PEIE = 1;
    ADCON1 = 0x0F;

    TRISB7 = 0;
    TRISB0 = 1;
    RB7 = 0;

    init_external_interrupt();
    GIE = 1;
    i = read_internal_eeprom(0x00);
    j = read_internal_eeprom(0x01);
    k = read_internal_eeprom(0x02);
    l = read_internal_eeprom(0x03);

    a = read_internal_eeprom(0x04);
    b = read_internal_eeprom(0x05);
    c = read_internal_eeprom(0x06);
    d = read_internal_eeprom(0x07);


}
void main(void) {
    init_config();
    while (1) {
        
        key = read_digital_keypad(STATE_CHANGE);
        if (flag == 0) {
            if (rec == 0) {
                ssd[0] = BLANK;
                ssd[1] = BLANK;
                ssd[2] = BLANK;
                ssd[3] = BLANK;
                display(ssd);
            } else if (rec == 1) {

                ssd[3] = digit[val % 10];
                ssd[2] = digit[(val / 10) % 10];
                ssd[1] = digit[(val / 100) % 10];
                ssd[0] = digit[(val / 1000)];
                display(ssd);
                if (key == SWITCH1) {
                    val++;
                    if(val>9999)
                    {
                        val=0000;
                    }
                } else if (key == SWITCH2) {
                    val--;
                    if(val<0000)
                    {
                        val=9999;
                    }
                } else if (key == SWITCH3) {
                    write_internal_eeprom(0x00, val % 10);
                    write_internal_eeprom(0x01, (val / 10) % 10);
                    write_internal_eeprom(0x02, (val / 100) % 10);
                    write_internal_eeprom(0x03, (val / 1000));
                    i = val % 10;
                    j = (val / 10) % 10;
                    k = (val / 100) % 10;
                    l = (val / 1000);
                    can_transmit();
                    val = 0;
                    rec = 0;
                }

            }

        }
        else if (flag == 1) 
        {
            if (flag2 == 0) 
            {
                if (flag1 == 0) {
                    ssd[3] = 0XCC;
                    ssd[2] = 0X6E;
                    ssd[1] = 0X08;
                    ssd[0] = 0XE5;
                } else {
                    ssd[3] = 0XE9;
                    ssd[2] = 0X80;
                    ssd[1] = 0X08;
                    ssd[0] = 0X8f;
                }
                display(ssd);
                if (key == SWITCH3 && flag2 == 0) {
                    flag1 = !flag1;
                } else if (key == SWITCH2 && flag1 == 0) {
                    flag2 = 1;
                } else if (key == SWITCH2 && flag1 != 0) {
                    flag2 = 2;
                }
            }
            else if (flag2 == 1) 
            {
                if (s_field == 0) {
                    ssd[3] = digit[i] | DOT;
                    ssd[2] = digit[j];
                    ssd[1] = digit[k];
                    ssd[0] = digit[l];
                } else if (s_field == 1) {
                    ssd[3] = digit[i];
                    ssd[2] = digit[j] | DOT;
                    ssd[1] = digit[k];
                    ssd[0] = digit[l];
                } else if (s_field == 2) {
                    ssd[3] = digit[i];
                    ssd[2] = digit[j];
                    ssd[1] = digit[k] | DOT;
                    ssd[0] = digit[l];

                } else if (s_field == 3) {
                    ssd[3] = digit[i];
                    ssd[2] = digit[j];
                    ssd[1] = digit[k];
                    ssd[0] = digit[l] | DOT;
                }
                if (key == SWITCH1 && flag2 == 1) {

                    if (s_field == 0) {
                        if (i++ >= 9) {
                            i = 0;
                        }
                    } else if (s_field == 1) {
                        if (j++ >= 9) {
                            j = 0;

                        }
                    } else if (s_field == 2) {
                        if (k++ >= 9) {
                            k = 0;

                        }
                    } else if (s_field == 3) {
                        if (l++ >= 9) {
                            l = 0;

                        }
                    }
                } else if (key == SWITCH2 && flag2 == 1) {
                    s_field = (s_field + 1) % 4;
                } else if (key == SWITCH3 && flag2 == 1) {
                    flag = 0;
                    flag1=0;
                    flag2=0;
                    p_field = 0;
                    s_field = 0;
                    write_internal_eeprom(0x00, i);
                    write_internal_eeprom(0x01, j);
                    write_internal_eeprom(0x02, k);
                    write_internal_eeprom(0x03, l);
                    can_transmit();
                }
                display(ssd);

            } 
            else if (flag2 == 2) 
            {
                if (p_field == 0) {
                    ssd[3] = digit[a] | DOT;
                    ssd[2] = digit[b];
                    ssd[1] = digit[c];
                    ssd[0] = digit[d];
                } else if (p_field == 1) {
                    ssd[3] = digit[a];
                    ssd[2] = digit[b] | DOT;
                    ssd[1] = digit[c];
                    ssd[0] = digit[d];
                } else if (p_field == 2) {
                    ssd[3] = digit[a];
                    ssd[2] = digit[b];
                    ssd[1] = digit[c] | DOT;
                    ssd[0] = digit[d];

                } else if (p_field == 3) {
                    ssd[3] = digit[a];
                    ssd[2] = digit[b];
                    ssd[1] = digit[c];
                    ssd[0] = digit[d] | DOT;
                }
                if (key == SWITCH1 && flag2 == 2) {

                    if (p_field == 0) {
                        if (a++ >= 9) {
                            a = 0;
                        }
                    } else if (p_field == 1) {
                        if (b++ >= 9) {
                            b = 0;

                        }
                    } else if (p_field == 2) {
                        if (c++ >= 9) {
                            c = 0;

                        }
                    } else if (p_field == 3) {
                        if (d++ >= 9) {
                            d = 0;

                        }
                    }
                } else if (key == SWITCH2 && flag2 == 2) {
                    p_field = (p_field + 1) % 4;
                } else if (key == SWITCH3 && flag2 == 2) {
                    flag = 0;
                    flag1=0;
                    flag2=0;
                    p_field = 0;
                    s_field = 0;
                    write_internal_eeprom(0x04, a);
                    write_internal_eeprom(0x05, b);
                    write_internal_eeprom(0x06, c);
                    write_internal_eeprom(0x07, d);
                }
                display(ssd);
            }
        }
        if(can_receive())
        {
            a = read_internal_eeprom(0x04);
            b = read_internal_eeprom(0x05);
            c = read_internal_eeprom(0x06);
            d = read_internal_eeprom(0x07);  
            if (((can_payload[D4]-'0') == d ) &&
                    ((can_payload[D5]-'0')== c  ) &&
                    ((can_payload[D6]-'0')== b  ) &&
                    ((can_payload[D7]-'0') == a  )) 
            {
                flag=0;
                rec=1;
                val=(can_payload[D3]-'0');
                val= val*10+(can_payload[D2]-'0');
                val= val*10+(can_payload[D1]-'0');
                val=val*10+(can_payload[D0]-'0');
                
            }  
        }
        
   
     }
    
}


