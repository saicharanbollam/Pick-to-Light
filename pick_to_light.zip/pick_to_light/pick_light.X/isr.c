#include <xc.h>
#include "isr.h"
extern unsigned int key_detected;
extern int flag;
void __interrupt() isr(void)
{
	if (INT0F == 1)
	{
        INT0F = 0;
        if(flag==0)
        {
            flag=1;
            
        }
        else
        {
            flag=0;
        }
        
	}
}