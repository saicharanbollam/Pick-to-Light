#include <xc.h>
#include "main.h"
#include "uart.h"
#include "can.h"
#include "clcd.h"

char data_to_send[4];
char receiver_id[4];
char ch;
unsigned long int i=0,flag=0,flag1=0,n=0;
void init_config(void)
{
	init_uart();
    /* Initialize CAN module */
	init_can();
	GIE = 1;
    PEIE = 1;
//    getch();
//    puts("Enter the receivers Node ID [Note: Max 4 digits, Extras would be trancated!]: ");
}

void main()
{
    char key;
	init_config();
    while(1)
    {
        if(can_receive())
        {  
            puts("\n\r");
            puts("Received Data: ID-");
            for(int e=4;e<8;e++)
            {
                putch(can_payload[D0+e]);
            }
            puts(":U-");
            for(int e=0;e<4;e++)
            {
                putch(can_payload[D0+e]);
            }   
            puts("\n\r");
            
        }
        
        if (ch == 13) 
        {
            puts("\n\r");
            if (flag1 == 0 && n==0) {
                
                puts("Enter the receivers Node ID [Note: Max 4 digits, Extras would be trancated!]: ");
                receiver_id[3] = '0';
                receiver_id[2] = '0';
                receiver_id[1] = '0';
                receiver_id[0] = '0';
                ch = '\0';
                i=0;
                n=1;
                flag = 1;
                flag1=1;
                
                
            }
            else if(flag1==1 && n==0)
            {
                puts("Enter the Data to be sent [Note: Max 4 bytes, Extras would be trancated!]: ");
                data_to_send[3] = '0';
                data_to_send[2] = '0';
                data_to_send[1] = '0';
                data_to_send[0] = '0';
                ch = '\0';
                i=0;
                n=1;
                flag = 2;
                flag1=0;
              
            }
           
        }
        
        if (flag == 1) {
            if (ch != '\0'  && ch != 13) 
            {
                if(ch>='0' && ch<='9')
                {
                  receiver_id[i] = ch;  
                  i++;
                }
                putch(ch);
                ch = '\0'; 
               
            }
            else if(ch==13)
            {
                if(i==1)
                {
                    receiver_id[3] = receiver_id[0];
                    receiver_id[2] = '0';
                    receiver_id[1] = '0';
                    receiver_id[0] = '0';    
                }
                else if(i==2)
                {
                    receiver_id[3] = receiver_id[1];
                    receiver_id[2] = receiver_id[0];
                    receiver_id[1] = '0';
                    receiver_id[0] = '0'; 
                }
                else if(i==3)
                {
                    receiver_id[3] = receiver_id[2];
                    receiver_id[2] = receiver_id[1];
                    receiver_id[1] = receiver_id[0];
                    receiver_id[0] = '0';
                }
                n=0,i=0;
                flag1 = 1;
                flag=0;
                
            }
        }
        if (flag == 2) {
            if (ch != '\0' && ch != 13) 
            {
                if(ch>='0' && ch<='9')
                {
                    data_to_send[i] = ch;
                    i++;
                }
                putch(ch);
                ch = '\0';    
            }
            else if(ch==13)
            {
                if(i==1)
                {
                    data_to_send[3] = data_to_send[0];
                    data_to_send[2] = '0';
                    data_to_send[1] = '0';
                    data_to_send[0] = '0';   
                }
                else if(i==2)
                {
                    data_to_send[3] = data_to_send[1];
                    data_to_send[2] = data_to_send[0];
                    data_to_send[1] = '0';
                    data_to_send[0] = '0';
                    
                }
                else if(i==3)
                {
                    data_to_send[3] = data_to_send[2];
                    data_to_send[2] = data_to_send[1];
                    data_to_send[1] = data_to_send[0];
                    data_to_send[0] = '0';
                }
                n=0,i=0;
                can_transmit();
                flag1 = 0;
                flag=0;
                
            }
        }
           
    }
        
       
         
    }




